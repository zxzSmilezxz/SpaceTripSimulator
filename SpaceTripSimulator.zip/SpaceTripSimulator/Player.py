class Playmen():
    def __init__(self,pos=0,score=0,monets=0,max_score=0):
        self.pos = pos
        self.score = score
        self.monets = monets
        self.max_score = max_score